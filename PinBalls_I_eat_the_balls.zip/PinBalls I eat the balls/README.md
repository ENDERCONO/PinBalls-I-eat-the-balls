# PinBalls - I eat the balls

## Description

A 2D pinball game made with raylib and Box2D 2.4.1. One ball, one life: get the best score you can.

## Key Features

 - Spring launcher and plunger lane (prismatic joint)
 - Two flippers with spring return and a small bounce
 - Bumpers, targets and very bouncy slingshots that give points
 - Score UI, Game Over screen and TRY AGAIN button
 
## Controls

 - A / Left arrow: left flipper
 - D / Right arrow: right flipper
 - ENTER / R / TRY AGAIN button: restart
 - F1: show physics debug

## Developers

 - {Dev01} - {Role(s)}
 - {Dev02} - {Role(s)}
 - {Dev03} - {Role(s)}
 - {Dev04} - {Role(s)}

## License

This project is licensed under an unmodified MIT license, which is an OSI-certified license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

{AdditionalLicenses}
