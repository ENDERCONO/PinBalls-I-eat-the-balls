#include "Globals.h"
#include "Application.h"
#include "ModuleRender.h"
#include "ModuleGame.h"
#include "ModuleAudio.h"
#include "ModulePhysics.h"

#include <math.h>
#include <stdio.h>

// Table coordinate -> window pixel
static int TX(int x)
{
	return TABLE_X + x;
}

static void DrawTextCentered(const char* text, int center_x, int y, int size, Color color)
{
	DrawText(text, center_x - MeasureText(text, size) / 2, y, size, color);
}

ModuleGame::ModuleGame(Application* app, bool start_enabled) : Module(app, start_enabled)
{
	state = STATE_PLAYING;
	score = 0;
	best_score = 0;
	hits = 0;

	ball = NULL;
	plunger = NULL;
	drain = NULL;

	plunger_state = PLUNGER_LOADED;
	plunger_timer = 0.0f;
	ball_stuck_timer = 0.0f;
	drain_hit = false;

	tex_background = Texture2D{ 0 };
	tex_table = Texture2D{ 0 };
	tex_ball = Texture2D{ 0 };
	tex_bumper = Texture2D{ 0 };
	tex_flipper = Texture2D{ 0 };
	tex_kicker = Texture2D{ 0 };
	tex_target = Texture2D{ 0 };
	tex_plunger = Texture2D{ 0 };

	fx_bumper = fx_kicker = fx_target = fx_flipper = fx_launch = fx_wall = fx_gameover = 0;
}

ModuleGame::~ModuleGame()
{}

// Load assets
bool ModuleGame::Start()
{
	LOG("Loading game assets");

	App->renderer->camera.x = App->renderer->camera.y = 0;

	LoadAssets();
	BuildTable();
	Restart();

	return true;
}

// Unload assets
bool ModuleGame::CleanUp()
{
	LOG("Unloading game");

	if (ball != NULL)
	{
		App->physics->DestroyBody(ball);
		ball = NULL;
	}

	for (PhysBody* body : bodies)
		App->physics->DestroyBody(body);

	bodies.clear();
	bumpers.clear();
	kickers.clear();
	targets.clear();
	plunger = NULL;
	drain = NULL;
	flipper_left.body = NULL;
	flipper_right.body = NULL;

	UnloadAssets();

	return true;
}

void ModuleGame::LoadAssets()
{
	tex_background = LoadTexture("Assets/background.png");
	tex_table = LoadTexture("Assets/table.png");
	tex_ball = LoadTexture("Assets/ball.png");
	tex_bumper = LoadTexture("Assets/bumper.png");
	tex_flipper = LoadTexture("Assets/flipper.png");
	tex_kicker = LoadTexture("Assets/kicker.png");
	tex_target = LoadTexture("Assets/target.png");
	tex_plunger = LoadTexture("Assets/plunger.png");

	// Smooth scaling: the textures are drawn smaller than their real size
	SetTextureFilter(tex_ball, TEXTURE_FILTER_BILINEAR);
	SetTextureFilter(tex_bumper, TEXTURE_FILTER_BILINEAR);
	SetTextureFilter(tex_flipper, TEXTURE_FILTER_BILINEAR);
	SetTextureFilter(tex_kicker, TEXTURE_FILTER_BILINEAR);
	SetTextureFilter(tex_target, TEXTURE_FILTER_BILINEAR);
	SetTextureFilter(tex_plunger, TEXTURE_FILTER_BILINEAR);

	fx_bumper = App->audio->LoadFx("Assets/bumper.wav");
	fx_kicker = App->audio->LoadFx("Assets/slingshot.wav");
	fx_target = App->audio->LoadFx("Assets/bonus.wav");
	fx_flipper = App->audio->LoadFx("Assets/flipper.wav");
	fx_launch = App->audio->LoadFx("Assets/launch.wav");
	fx_wall = App->audio->LoadFx("Assets/wall.wav");
	fx_gameover = App->audio->LoadFx("Assets/gameover.wav");
}

void ModuleGame::UnloadAssets()
{
	UnloadTexture(tex_background);
	UnloadTexture(tex_table);
	UnloadTexture(tex_ball);
	UnloadTexture(tex_bumper);
	UnloadTexture(tex_flipper);
	UnloadTexture(tex_kicker);
	UnloadTexture(tex_target);
	UnloadTexture(tex_plunger);
}

PhysBody* ModuleGame::AddBody(PhysBody* body, int kind, int points)
{
	body->kind = kind;
	body->points = points;
	bodies.push_back(body);
	return body;
}

// ---------------------------------------------------------------------------------------------
// Table: walls, flippers, plunger, bumpers, slingshots and targets
// ---------------------------------------------------------------------------------------------
void ModuleGame::BuildTable()
{
	ModulePhysics* physics = App->physics;

	// 1) Outer shell: right wall of the launch lane, a half circle arc on top, left wall and the
	//    slope that guides the ball to the left flipper. It is an OPEN chain (loop = false)
	std::vector<int> shell;
	shell.push_back(490); shell.push_back(700);
	shell.push_back(490); shell.push_back(250);
	for (int i = 1; i <= 36; ++i)
	{
		float a = (float)i * PI / 36.0f;
		shell.push_back((int)(250.0f + 240.0f * cosf(a)));
		shell.push_back((int)(250.0f - 240.0f * sinf(a)));
	}
	shell.push_back(10);  shell.push_back(520);
	shell.push_back(118); shell.push_back(596);
	AddBody(physics->CreateChain(TABLE_X, 0, shell.data(), (int)shell.size(), false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 2) Wall between the launch lane (right) and the playfield. It ends before the arc so the
	//    ball can leave the lane
	const int lane_wall[] = { 455, 700, 455, 200 };
	AddBody(physics->CreateChain(TABLE_X, 0, lane_wall, 4, false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 3) Slope that guides the ball to the right flipper
	const int right_guide[] = { 455, 520, 350, 597 };
	AddBody(physics->CreateChain(TABLE_X, 0, right_guide, 4, false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 4) Drain: sensor below the screen. Ball touches it = game over
	drain = AddBody(physics->CreateRectangleSensor(TABLE_X + TABLE_W / 2, TABLE_H + 40, TABLE_W / 2 + 20, 28), KIND_DRAIN);
	drain->listener = this;

	// 5) Plunger. Its body is created at the compressed position
	plunger = AddBody(physics->CreatePlunger(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y, 15, 10, PLUNGER_COMPRESSED_Y - PLUNGER_REST_Y), KIND_PLUNGER);

	// 6) Flippers: kinematic bodies (we move them, they push the ball but nothing pushes them).
	//    The polygon is built from the pivot (0, 0) towards +X
	const int flipper_shape[] =
	{
		-10, -6,
		-10,  6,
		  0, 13,
		FLIPPER_LENGTH,  7,
		FLIPPER_LENGTH, -7,
		  0, -13
	};

	// Right flipper: rests at -210 degrees and rises 45 degrees to -165
	// Left flipper: mirror image, rests at +30 and rises to -15
	// (see the document: Box2D here has Y pointing down, so left and right use opposite signs)
	flipper_left.left = true;
	flipper_left.rest_angle = 30.0f * DEGTORAD;
	flipper_left.pressed_angle = (30.0f - FLIPPER_SWING_DEG) * DEGTORAD;
	flipper_left.body = AddBody(physics->CreatePolygon(TX(126), 600, flipper_shape, 12, b2_kinematicBody, 0.2f, 0.4f, 30.0f), KIND_FLIPPER);

	flipper_right.left = false;
	flipper_right.rest_angle = -210.0f * DEGTORAD;
	flipper_right.pressed_angle = (-210.0f + FLIPPER_SWING_DEG) * DEGTORAD;
	flipper_right.body = AddBody(physics->CreatePolygon(TX(338), 600, flipper_shape, 12, b2_kinematicBody, 0.2f, 0.4f, -210.0f), KIND_FLIPPER);

	// 7) Slingshots (very bouncy triangles above the flippers)
	const int kicker_left_shape[] = { 40, 430,  40, 500,  100, 535 };
	const int kicker_right_shape[] = { 425, 430,  425, 500,  365, 535 };

	Kicker kl = { AddBody(physics->CreatePolygon(TABLE_X, 0, kicker_left_shape, 6, b2_staticBody, SLINGSHOT_RESTITUTION, 0.0f), KIND_BOUNCY, POINTS_SLINGSHOT), TX(36), 426, false };
	Kicker kr = { AddBody(physics->CreatePolygon(TABLE_X, 0, kicker_right_shape, 6, b2_staticBody, SLINGSHOT_RESTITUTION, 0.0f), KIND_BOUNCY, POINTS_SLINGSHOT), TX(361), 426, true };
	kickers.push_back(kl);
	kickers.push_back(kr);

	// 8) Bumpers: round, they give points and bounce the ball
	const int bumper_pos[][2] = { { 215, 300 }, { 130, 235 }, { 335, 235 } };
	for (int i = 0; i < 3; ++i)
	{
		Bumper b;
		b.x = TX(bumper_pos[i][0]);
		b.y = bumper_pos[i][1];
		b.radius = 26;
		b.body = AddBody(physics->CreateCircle(b.x, b.y, b.radius, b2_staticBody, BUMPER_RESTITUTION, 0.0f), KIND_BUMPER, POINTS_BUMPER);
		bumpers.push_back(b);
	}

	// 9) Stand-up targets on both side walls
	const int target_pos[][2] = { { 22, 330 }, { 443, 330 } };
	for (int i = 0; i < 2; ++i)
	{
		Target t;
		t.x = TX(target_pos[i][0]);
		t.y = target_pos[i][1];
		t.half_w = 6;
		t.half_h = 25;
		t.body = AddBody(physics->CreateRectangle(t.x, t.y, t.half_w, t.half_h, b2_staticBody, TARGET_RESTITUTION, 0.1f), KIND_TARGET, POINTS_TARGET);
		targets.push_back(t);
	}
}

// ---------------------------------------------------------------------------------------------
// Game flow
// ---------------------------------------------------------------------------------------------
void ModuleGame::SpawnBall()
{
	if (ball != NULL)
	{
		App->physics->DestroyBody(ball);
		ball = NULL;
	}

	// Right side of the table, lying on top of the compressed plunger
	ball = App->physics->CreateCircle(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y - 10 - BALL_RADIUS - 1, BALL_RADIUS, b2_dynamicBody, 0.3f, 0.1f, true);
	ball->kind = KIND_BALL;
	ball->listener = this;
	ball->body->SetSleepingAllowed(false);
}

void ModuleGame::Restart()
{
	state = STATE_PLAYING;
	score = 0;
	hits = 0;
	drain_hit = false;
	ball_stuck_timer = 0.0f;
	popups.clear();

	// Flippers back to their initial rotation
	Flipper* flippers[2] = { &flipper_left, &flipper_right };
	for (Flipper* f : flippers)
	{
		f->angle = f->rest_angle;
		f->omega = 0.0f;
		f->was_pressed = false;
		f->body->body->SetTransform(f->body->body->GetPosition(), f->rest_angle);
		f->body->SetAngularVelocity(0.0f);
	}

	// Compress the spring and wait: UpdatePlunger() will release it
	plunger_state = PLUNGER_LOADED;
	plunger_timer = PLUNGER_LAUNCH_DELAY;
	plunger->SetPosition(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y);
	plunger->SetLinearVelocity(0.0f, 0.0f);

	SpawnBall();
}

void ModuleGame::GameOver()
{
	state = STATE_GAME_OVER;

	if (score > best_score)
		best_score = score;

	// The ball is not needed any more
	App->physics->DestroyBody(ball);
	ball = NULL;

	// Freeze the flippers where they are
	flipper_left.body->SetAngularVelocity(0.0f);
	flipper_right.body->SetAngularVelocity(0.0f);

	App->audio->PlayFx(fx_gameover);
}

void ModuleGame::AddScore(int value, int x, int y)
{
	score += value;
	hits++;

	Popup p = { (float)x, (float)y, 0.8f, value };
	popups.push_back(p);
}

// ---------------------------------------------------------------------------------------------
// Per frame logic
// ---------------------------------------------------------------------------------------------

// The flipper is a kinematic body: instead of teleporting it, we give it the angular velocity that
// makes it reach the animated angle in exactly one physics step. That way the ball is pushed with
// the real speed of the flipper.
void ModuleGame::UpdateFlipper(Flipper& flipper, bool pressed, float dt)
{
	if (pressed && flipper.was_pressed == false)
		App->audio->PlayFx(fx_flipper);

	if (pressed)
	{
		// Rotate 45 degrees in FLIPPER_RISE_TIME seconds, then hold
		float speed = (FLIPPER_SWING_DEG * DEGTORAD) / FLIPPER_RISE_TIME;
		float direction = (flipper.pressed_angle > flipper.rest_angle) ? 1.0f : -1.0f;

		flipper.angle += direction * speed * dt;

		if ((direction > 0.0f && flipper.angle >= flipper.pressed_angle) ||
			(direction < 0.0f && flipper.angle <= flipper.pressed_angle))
			flipper.angle = flipper.pressed_angle;

		flipper.omega = 0.0f;
	}
	else
	{
		// Released: damped spring towards the rest angle. Damping ratio < 1 = it passes the rest
		// angle a little bit and comes back (the "bounce")
		float k = FLIPPER_SPRING_FREQ * FLIPPER_SPRING_FREQ;
		float c = 2.0f * FLIPPER_DAMPING * FLIPPER_SPRING_FREQ;

		flipper.omega += (k * (flipper.rest_angle - flipper.angle) - c * flipper.omega) * dt;
		flipper.angle += flipper.omega * dt;

		if (fabsf(flipper.rest_angle - flipper.angle) < 0.0005f && fabsf(flipper.omega) < 0.01f)
		{
			flipper.angle = flipper.rest_angle;
			flipper.omega = 0.0f;
		}
	}

	float current_angle = flipper.body->GetRotation();
	flipper.body->SetAngularVelocity((flipper.angle - current_angle) / dt);

	flipper.was_pressed = pressed;
}

void ModuleGame::UpdatePlunger(float dt)
{
	if (plunger_state == PLUNGER_LOADED)
	{
		// Hold the plunger compressed
		plunger->SetPosition(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y);
		plunger->SetLinearVelocity(0.0f, 0.0f);

		plunger_timer -= dt;
		if (plunger_timer <= 0.0f)
		{
			plunger_state = PLUNGER_RELEASED;
			App->audio->PlayFx(fx_launch);
		}
	}
	else
	{
		// Spring (Hooke's law): F = -k * x, x = distance below the rest position.
		// The prismatic joint upper limit stops the plunger at the rest position, so the ball
		// leaves with the speed the plunger had at that moment
		float x = PIXEL_TO_METERS(plunger->GetY() - (float)PLUNGER_REST_Y);
		if (x > 0.0f)
			plunger->ApplyForce(0.0f, -PLUNGER_SPRING_K * x);

		// If the ball falls back into the lane, load the spring and shoot again
		if (ball != NULL)
		{
			int bx, by;
			ball->GetPosition(bx, by);

			bool in_lane = (bx > TX(455) && by > 300);
			if (in_lane && ball->GetSpeed() < 0.3f)
				ball_stuck_timer += dt;
			else
				ball_stuck_timer = 0.0f;

			if (ball_stuck_timer > 0.6f)
			{
				ball_stuck_timer = 0.0f;
				plunger_state = PLUNGER_LOADED;
				plunger_timer = 0.8f;
			}
		}
	}
}

void ModuleGame::UpdateEffects(float dt)
{
	for (Bumper& b : bumpers)
		if (b.body->flash > 0.0f) b.body->flash -= dt;

	for (Kicker& k : kickers)
		if (k.body->flash > 0.0f) k.body->flash -= dt;

	for (Target& t : targets)
		if (t.body->flash > 0.0f) t.body->flash -= dt;

	for (size_t i = 0; i < popups.size();)
	{
		popups[i].timer -= dt;
		popups[i].y -= 30.0f * dt;

		if (popups[i].timer <= 0.0f)
			popups.erase(popups.begin() + i);
		else
			++i;
	}
}

update_status ModuleGame::Update()
{
	const float dt = 1.0f / 60.0f; // same fixed step as ModulePhysics::PreUpdate()

	if (state == STATE_PLAYING)
	{
		bool left_pressed = IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT);
		bool right_pressed = IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT);

		UpdateFlipper(flipper_left, left_pressed, dt);
		UpdateFlipper(flipper_right, right_pressed, dt);
		UpdatePlunger(dt);

		if (ball != NULL)
		{
			// Safety: never let the ball go faster than the physics can handle
			if (ball->GetSpeed() > BALL_MAX_SPEED)
			{
				float vx, vy;
				ball->GetVelocity(vx, vy);
				float s = BALL_MAX_SPEED / ball->GetSpeed();
				ball->SetLinearVelocity(vx * s, vy * s);
			}

			// The ball reached the bottom of the map (Y max): the sensor tells us, and we also
			// check the position in case it ever misses
			if (drain_hit || ball->GetY() > (float)(TABLE_H + 60))
				GameOver();
		}
	}
	else
	{
		if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_R))
			Restart();
	}

	UpdateEffects(dt);

	// Draw (back to front)
	DrawBackground();
	DrawTable();
	DrawFlippers();
	DrawBall();
	DrawUI();

	if (state == STATE_GAME_OVER)
		DrawGameOver();

	return UPDATE_CONTINUE;
}

// The ball tells us what it touched. ModulePhysics calls this for every body with a listener
void ModuleGame::OnCollision(PhysBody* bodyA, PhysBody* bodyB)
{
	if (state != STATE_PLAYING || bodyA == NULL || bodyB == NULL)
		return;

	// Ball in the drain. It is called twice (ball,sensor) and (sensor,ball): both set the same flag
	if ((bodyA->kind == KIND_DRAIN && bodyB->kind == KIND_BALL) || (bodyA->kind == KIND_BALL && bodyB->kind == KIND_DRAIN))
	{
		// Never destroy bodies inside a collision callback: the world is locked.
		// Just remember it and do it in Update()
		drain_hit = true;
		return;
	}

	// From here on we only care about the callback of the ball (A = ball, B = what it touched)
	if (bodyA->kind != KIND_BALL)
		return;

	int bx, by;
	bodyA->GetPosition(bx, by);

	switch (bodyB->kind)
	{
	case KIND_BUMPER:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.15f;
		App->audio->PlayFx(fx_bumper);
		break;

	case KIND_TARGET:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.2f;
		App->audio->PlayFx(fx_target);
		break;

	case KIND_BOUNCY:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.12f;
		App->audio->PlayFx(fx_kicker);
		break;

	case KIND_WALL:
		// Only the hard hits make noise, otherwise rolling along a wall sounds like a machine gun
		if (bodyA->GetSpeed() > 3.0f)
			App->audio->PlayFx(fx_wall);
		break;

	default:
		break;
	}
}

// ---------------------------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------------------------
void ModuleGame::DrawBackground()
{
	DrawTexture(tex_background, 0, 0, WHITE);
	DrawTexture(tex_table, TABLE_X, 0, WHITE);
}

void ModuleGame::DrawTable()
{
	// Slingshots (the texture is the left one, the right one is the same image mirrored)
	for (const Kicker& k : kickers)
	{
		Rectangle source = { 0.0f, 0.0f, k.mirrored ? -(float)tex_kicker.width : (float)tex_kicker.width, (float)tex_kicker.height };
		Rectangle dest = { (float)k.x, (float)k.y, 68.0f, 113.0f };
		Color tint = (k.body->flash > 0.0f) ? Color{ 255, 255, 140, 255 } : WHITE;
		DrawTexturePro(tex_kicker, source, dest, Vector2{ 0.0f, 0.0f }, 0.0f, tint);
	}

	// Targets
	for (const Target& t : targets)
	{
		Rectangle source = { 0.0f, 0.0f, (float)tex_target.width, (float)tex_target.height };
		Rectangle dest = { (float)t.x, (float)t.y, 12.0f, 50.0f };
		Color tint = (t.body->flash > 0.0f) ? Color{ 255, 255, 140, 255 } : WHITE;
		DrawTexturePro(tex_target, source, dest, Vector2{ 6.0f, 25.0f }, 0.0f, tint);
	}

	// Bumpers: they grow a bit when they are hit
	for (const Bumper& b : bumpers)
	{
		float scale = 1.0f + 0.25f * (b.body->flash > 0.0f ? b.body->flash / 0.15f : 0.0f);
		float diameter = (float)b.radius * 2.0f * 1.15f * scale;
		Rectangle source = { 0.0f, 0.0f, (float)tex_bumper.width, (float)tex_bumper.height };
		Rectangle dest = { (float)b.x, (float)b.y, diameter, diameter };
		Color tint = (b.body->flash > 0.0f) ? Color{ 255, 255, 170, 255 } : WHITE;
		DrawTexturePro(tex_bumper, source, dest, Vector2{ diameter / 2.0f, diameter / 2.0f }, 0.0f, tint);
	}

	// Plunger: zig-zag spring from the head down to the bottom of the lane + head texture
	int px, py;
	plunger->GetPosition(px, py);
	float top = (float)py + 10.0f;
	float bottom = (float)TABLE_H - 20.0f;
	const int coils = 9;
	for (int i = 0; i < coils; ++i)
	{
		float y1 = top + (bottom - top) * (float)i / (float)coils;
		float y2 = top + (bottom - top) * (float)(i + 1) / (float)coils;
		float x1 = (float)px + ((i % 2 == 0) ? -9.0f : 9.0f);
		float x2 = (float)px + ((i % 2 == 0) ? 9.0f : -9.0f);
		DrawLineEx(Vector2{ x1, y1 }, Vector2{ x2, y2 }, 3.0f, Color{ 190, 190, 205, 255 });
	}

	Rectangle source = { 0.0f, 0.0f, (float)tex_plunger.width, (float)tex_plunger.height };
	Rectangle dest = { (float)px, (float)py, 30.0f, 20.0f };
	DrawTexturePro(tex_plunger, source, dest, Vector2{ 15.0f, 10.0f }, 0.0f, WHITE);
}

void ModuleGame::DrawFlippers()
{
	Flipper* flippers[2] = { &flipper_left, &flipper_right };

	for (Flipper* f : flippers)
	{
		int x, y;
		f->body->GetPosition(x, y);

		// The texture is 104 x 32 and its pivot is at (12, 16). The right flipper has the angle
		// of the left one + 180 degrees, so it is drawn upside down: flip it vertically
		Rectangle source = { 0.0f, 0.0f, (float)tex_flipper.width, f->left ? (float)tex_flipper.height : -(float)tex_flipper.height };
		Rectangle dest = { (float)x, (float)y, 104.0f, 32.0f };
		DrawTexturePro(tex_flipper, source, dest, Vector2{ 12.0f, 16.0f }, f->body->GetRotation() * RAD2DEG, WHITE);
	}
}

void ModuleGame::DrawBall()
{
	if (ball == NULL)
		return;

	int x, y;
	ball->GetPosition(x, y);

	float d = (float)BALL_RADIUS * 2.0f;
	Rectangle source = { 0.0f, 0.0f, (float)tex_ball.width, (float)tex_ball.height };
	Rectangle dest = { (float)x, (float)y, d, d };
	DrawTexturePro(tex_ball, source, dest, Vector2{ d / 2.0f, d / 2.0f }, ball->GetRotation() * RAD2DEG, WHITE);
}

void ModuleGame::DrawUI()
{
	// Floating "+100" where the points were earned
	for (const Popup& p : popups)
	{
		unsigned char alpha = (unsigned char)(255.0f * (p.timer / 0.8f));
		DrawText(TextFormat("+%d", p.value), (int)p.x - 14, (int)p.y - 30, 22, Color{ 255, 240, 120, alpha });
	}

	// Left panel: score
	const int left_center = (TABLE_X) / 2;
	Rectangle panel = { 30.0f, 40.0f, (float)(TABLE_X - 60), 330.0f };
	DrawRectangleRounded(panel, 0.06f, 8, Color{ 10, 8, 30, 200 });
	DrawRectangleLinesEx(panel, 3.0f, Color{ 90, 220, 255, 255 });

	DrawTextCentered("PINBALLS", left_center, 60, 40, Color{ 255, 90, 200, 255 });
	DrawTextCentered("SCORE", left_center, 130, 22, Color{ 150, 170, 210, 255 });
	DrawTextCentered(TextFormat("%07d", score), left_center, 160, 52, Color{ 255, 230, 90, 255 });
	DrawTextCentered("BEST", left_center, 240, 22, Color{ 150, 170, 210, 255 });
	DrawTextCentered(TextFormat("%07d", best_score), left_center, 268, 32, Color{ 120, 240, 255, 255 });
	DrawTextCentered(TextFormat("HITS  %d", hits), left_center, 322, 22, Color{ 150, 170, 210, 255 });

	// Right panel: controls
	const int right_x = TABLE_X + TABLE_W + 60;
	const int right_center = right_x + (TABLE_X - 120) / 2;
	Rectangle panel2 = { (float)right_x, 40.0f, (float)(TABLE_X - 90), 250.0f };
	DrawRectangleRounded(panel2, 0.06f, 8, Color{ 10, 8, 30, 200 });
	DrawRectangleLinesEx(panel2, 3.0f, Color{ 90, 220, 255, 255 });

	DrawTextCentered("CONTROLS", right_center, 60, 28, Color{ 255, 90, 200, 255 });
	DrawText("A / <-   left flipper", right_x + 20, 115, 20, WHITE);
	DrawText("D / ->   right flipper", right_x + 20, 150, 20, WHITE);
	DrawText("ENTER    try again", right_x + 20, 185, 20, WHITE);
	DrawText("F1       debug physics", right_x + 20, 220, 20, WHITE);
}

void ModuleGame::DrawGameOver()
{
	const int cx = SCREEN_WIDTH / 2;

	DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Color{ 0, 0, 0, 175 });

	DrawTextCentered("GAME OVER", cx, 190, 84, Color{ 255, 70, 90, 255 });
	DrawTextCentered(TextFormat("SCORE  %07d", score), cx, 305, 36, Color{ 255, 230, 90, 255 });

	if (score > 0 && score >= best_score)
		DrawTextCentered("NEW RECORD!", cx, 355, 28, Color{ 120, 240, 255, 255 });

	// TRY AGAIN button
	Rectangle button = { (float)(cx - 130), 420.0f, 260.0f, 70.0f };
	bool hover = CheckCollisionPointRec(GetMousePosition(), button);

	DrawRectangleRounded(button, 0.3f, 8, hover ? Color{ 255, 120, 210, 255 } : Color{ 190, 50, 150, 255 });
	DrawRectangleLinesEx(button, 3.0f, WHITE);
	DrawTextCentered("TRY AGAIN", cx, 440, 32, WHITE);

	if (hover && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
		Restart();
}
