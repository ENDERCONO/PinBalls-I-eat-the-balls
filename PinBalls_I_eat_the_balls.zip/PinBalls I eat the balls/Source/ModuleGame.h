#pragma once

#include "Globals.h"
#include "Module.h"

#include "p2Point.h"

#include "raylib.h"
#include <vector>

class PhysBody;

// ---------------------------------------------------------------------------------------------
// Table layout. The table is a 500 x 720 rectangle centered in the 1280 x 720 window.
// All the geometry in ModuleGame.cpp is written in TABLE coordinates (0,0 = top-left corner of
// the table) and converted to window pixels adding TABLE_X.
// ---------------------------------------------------------------------------------------------
#define TABLE_W 500
#define TABLE_H 720
#define TABLE_X ((SCREEN_WIDTH - TABLE_W) / 2)

// Ball
#define BALL_RADIUS         12
#define BALL_MAX_SPEED      30.0f   // m/s, safety clamp

// Flippers. Angles are the ones Box2D uses (degrees, Y axis down, positive = clockwise on screen)
#define FLIPPER_LENGTH      90
#define FLIPPER_SWING_DEG   45.0f   // how much the flipper rotates when the key is pressed
#define FLIPPER_RISE_TIME   0.07f   // seconds to rotate those 45 degrees
#define FLIPPER_SPRING_FREQ 22.0f   // rad/s: how fast it comes back when you release the key
#define FLIPPER_DAMPING     0.55f   // < 1 means it overshoots a little = the "bounce" (0.55 -> ~4 degrees)

// Plunger (the spring that launches the ball)
#define PLUNGER_X           472
#define PLUNGER_REST_Y      650     // where the spring is relaxed (and where it stops the plunger)
#define PLUNGER_COMPRESSED_Y 690    // where the plunger is held before the launch
#define PLUNGER_SPRING_K    150.0f  // N/m : bigger = stronger launch
#define PLUNGER_LAUNCH_DELAY 1.0f   // seconds the ball waits before the spring is released

// Materials
#define WALL_RESTITUTION    0.25f
#define BUMPER_RESTITUTION  0.9f
#define TARGET_RESTITUTION  0.5f
#define SLINGSHOT_RESTITUTION 1.4f  // > 1: the slingshot adds energy to the ball

// Points
#define POINTS_BUMPER       100
#define POINTS_TARGET       50
#define POINTS_SLINGSHOT    10

enum GameState
{
	STATE_PLAYING,
	STATE_GAME_OVER
};

enum PlungerState
{
	PLUNGER_LOADED,     // compressed, waiting
	PLUNGER_RELEASED    // the spring is pushing / resting
};

class ModuleGame : public Module
{
public:
	ModuleGame(Application* app, bool start_enabled = true);
	~ModuleGame();

	bool Start();
	update_status Update();
	bool CleanUp();

	void OnCollision(PhysBody* bodyA, PhysBody* bodyB) override;

private:

	struct Flipper
	{
		PhysBody* body = NULL;
		bool left = false;
		float rest_angle = 0.0f;     // radians
		float pressed_angle = 0.0f;  // radians
		float angle = 0.0f;          // current animated angle
		float omega = 0.0f;          // current angular speed
		bool was_pressed = false;
	};

	struct Popup
	{
		float x, y;
		float timer;
		int value;
	};

	struct Bumper
	{
		PhysBody* body;
		int x, y, radius;   // window pixels
	};

	struct Kicker       // slingshot
	{
		PhysBody* body;
		int x, y;           // window pixels, top-left corner of its texture
		bool mirrored;
	};

	struct Target
	{
		PhysBody* body;
		int x, y, half_w, half_h;   // window pixels, center
	};

	// Setup
	void BuildTable();
	void LoadAssets();
	void UnloadAssets();

	// Game flow
	void SpawnBall();
	void Restart();
	void GameOver();
	void AddScore(int value, int x, int y);

	// Per frame logic
	void UpdateFlipper(Flipper& flipper, bool pressed, float dt);
	void UpdatePlunger(float dt);
	void UpdateEffects(float dt);

	// Drawing
	void DrawBackground();
	void DrawTable();
	void DrawFlippers();
	void DrawBall();
	void DrawUI();
	void DrawGameOver();

	PhysBody* AddBody(PhysBody* body, int kind, int points = 0);

private:
	GameState state;
	int score;
	int best_score;
	int hits;

	// Physics objects
	std::vector<PhysBody*> bodies;     // every body this module created (to free them)
	PhysBody* ball;
	PhysBody* plunger;
	PhysBody* drain;
	Flipper flipper_left;
	Flipper flipper_right;
	std::vector<Bumper> bumpers;
	std::vector<Kicker> kickers;
	std::vector<Target> targets;

	PlungerState plunger_state;
	float plunger_timer;
	float ball_stuck_timer;
	bool drain_hit;

	std::vector<Popup> popups;

	// Textures
	Texture2D tex_background;
	Texture2D tex_table;
	Texture2D tex_ball;
	Texture2D tex_bumper;
	Texture2D tex_flipper;
	Texture2D tex_kicker;
	Texture2D tex_target;
	Texture2D tex_plunger;

	// Sounds
	uint32 fx_bumper;
	uint32 fx_kicker;
	uint32 fx_target;
	uint32 fx_flipper;
	uint32 fx_launch;
	uint32 fx_wall;
	uint32 fx_gameover;
};
