//*CHANGED*// This whole file was rewritten: the original had the demo classes (PhysicEntity, Circle, Box, Chain, Rick)
#pragma once

#include "Globals.h"
#include "Module.h"

#include "p2Point.h"

#include "raylib.h"
#include <vector>

class PhysBody;

// ---------------------------------------------------------------------------------------------
//*CHANGED*// Table layout. The table is a 500 x 720 rectangle centered in the 1280 x 720 window.
// All the geometry in ModuleGame.cpp is written in TABLE coordinates (0,0 = top-left corner of
// the table) and converted to window pixels adding TABLE_X.
// ---------------------------------------------------------------------------------------------
#define TABLE_W 500
#define TABLE_H 720
#define TABLE_X ((SCREEN_WIDTH - TABLE_W) / 2)

//*CHANGED*// Ball
#define BALL_RADIUS         12
#define BALL_MAX_SPEED      30.0f   // m/s, safety clamp
#define TRAIL_LENGTH        7       // old positions drawn behind the ball

//*CHANGED*// Flippers. Angles are the ones Box2D uses (degrees, Y axis down, positive = clockwise on screen)
#define FLIPPER_LENGTH      90
#define FLIPPER_SWING_DEG   45.0f   // how much the flipper rotates when the key is pressed
#define FLIPPER_RISE_TIME   0.07f   // seconds to rotate those 45 degrees
#define FLIPPER_SPRING_FREQ 22.0f   // rad/s: how fast it comes back when you release the key
#define FLIPPER_DAMPING     0.55f   // < 1 means it overshoots a little = the "bounce" (0.55 -> ~4 degrees)

//*CHANGED*// Plunger (the spring that launches the ball)
#define PLUNGER_X           472
#define PLUNGER_REST_Y      650     // where the spring is relaxed (and where it stops the plunger)
#define PLUNGER_COMPRESSED_Y 690    // where the plunger is held before the launch
#define PLUNGER_SPRING_K    150.0f  // N/m : bigger = stronger launch
#define PLUNGER_LAUNCH_DELAY 1.0f   // seconds the ball waits before the spring is released

//*CHANGED*// Materials (restitution = bounciness)
#define WALL_RESTITUTION    0.25f
#define BUMPER_RESTITUTION  0.9f
#define TARGET_RESTITUTION  0.5f
#define DIAMOND_RESTITUTION 1.1f
#define MOVER_RESTITUTION   0.6f
#define SLINGSHOT_RESTITUTION 1.4f  // > 1: the slingshot adds energy to the ball

//*CHANGED*// Points
#define POINTS_BUMPER       100
#define POINTS_TARGET       50
#define POINTS_TARGET_LIT   10      // target that was already hit in this bank
#define POINTS_BANK_BONUS   500     // all the targets hit
#define POINTS_DIAMOND      30
#define POINTS_MOVER        20
#define POINTS_SLINGSHOT    10

//*CHANGED*//
enum GameState
{
	STATE_PLAYING,
	STATE_GAME_OVER
};

//*CHANGED*//
enum PlungerState
{
	PLUNGER_LOADED,     // compressed, waiting
	PLUNGER_RELEASED    // the spring is pushing / resting
};

class ModuleGame : public Module
{
public:
	ModuleGame(Application* app, bool start_enabled = true);
	~ModuleGame();

	bool Start();
	update_status Update();
	bool CleanUp();

	void OnCollision(PhysBody* bodyA, PhysBody* bodyB) override;

private:

	//*CHANGED*// Everything below is new
	struct Flipper
	{
		PhysBody* body = NULL;
		bool left = false;
		float rest_angle = 0.0f;     // radians
		float pressed_angle = 0.0f;  // radians
		float angle = 0.0f;          // current animated angle
		float omega = 0.0f;          // current angular speed
		bool was_pressed = false;
	};

	struct Popup
	{
		float x, y;
		float timer;
		int value;
		bool bonus;
	};

	struct Particle
	{
		float x, y, vx, vy;
		float life;
		Color color;
	};

	struct Bumper
	{
		PhysBody* body;
		int x, y, radius;   // window pixels
	};

	struct Diamond          // rotated square, bouncy
	{
		PhysBody* body;
		int x, y;           // window pixels, center
	};

	struct Kicker           // slingshot
	{
		PhysBody* body;
		int x, y;           // window pixels, top-left corner of its texture
		bool mirrored;
	};

	struct Target
	{
		PhysBody* body;
		int x, y, half_w, half_h;   // window pixels, center
		bool lit;                   // already hit in this bank
	};

	// Platforms that move on their own (kinematic bodies): sliding platforms and the spinner
	struct Mover
	{
		PhysBody* body;
		float cx, cy;       // center of the movement, window pixels
		float ax, ay;       // amplitude of the movement in X and Y, pixels
		float speed;        // rad/s (the angular speed of the body if it is a spinner)
		float phase;
		bool spinner;       // true: rotates forever, false: slides
		int half_w, half_h; // pixels
		int texture;        // 0 = wide platform, 1 = small platform, 2 = spinner bar
	};

	// Setup
	void BuildTable();
	void LoadAssets();
	void UnloadAssets();

	// Game flow
	void SpawnBall();
	void RespawnBall();
	void Restart();
	void GameOver();
	void AddScore(int value, int x, int y, bool bonus = false);
	void SpawnParticles(int x, int y, int count, Color color);

	// Per frame logic
	void UpdateFlipper(Flipper& flipper, bool pressed, float dt);
	void UpdatePlunger(float dt);
	void UpdateMovers(float dt);
	void UpdateBallSafety(float dt);
	void UpdateEffects(float dt);

	// Drawing (pixel art: sprites are half size and snapped to even pixels)
	void DrawSprite(Texture2D tex, float x, float y, float w, float h, float ox, float oy, float rotation_deg = 0.0f, bool flip_x = false, bool flip_y = false);
	void DrawBackground();
	void DrawTable();
	void DrawFlippers();
	void DrawBall();
	void DrawUI();
	void DrawPanel(int x, int y, int w, int h);
	void DrawGameOver();

	PhysBody* AddBody(PhysBody* body, int kind, int points = 0);

private:
	GameState state;
	int score;
	int best_score;
	int hits;

	// Physics objects
	std::vector<PhysBody*> bodies;     // every body this module created (to free them)
	PhysBody* ball;
	PhysBody* plunger;
	PhysBody* drain;
	Flipper flipper_left;
	Flipper flipper_right;
	std::vector<Bumper> bumpers;
	std::vector<Diamond> diamonds;
	std::vector<Kicker> kickers;
	std::vector<Target> targets;
	std::vector<Mover> movers;

	PlungerState plunger_state;
	float plunger_timer;
	float ball_stuck_timer;     // ball in the lane, not moving
	float ball_idle_timer;      // ball in the playfield, not moving
	float mover_time;
	float bank_timer;           // > 0: the bank bonus was just won, the lights go off when it ends
	bool drain_hit;

	std::vector<Popup> popups;
	std::vector<Particle> particles;
	float trail_x[TRAIL_LENGTH];
	float trail_y[TRAIL_LENGTH];
	int trail_count;

	// Textures (pixel art, half the size they are drawn at)
	Texture2D tex_background;
	Texture2D tex_table;
	Texture2D tex_ball;
	Texture2D tex_bumper, tex_bumper_hit;
	Texture2D tex_diamond, tex_diamond_hit;
	Texture2D tex_flipper;
	Texture2D tex_kicker, tex_kicker_hit;
	Texture2D tex_target, tex_target_lit;
	Texture2D tex_plunger;
	Texture2D tex_platform_wide, tex_platform_small, tex_spinner;

	// Sounds
	uint32 fx_bumper;
	uint32 fx_kicker;
	uint32 fx_target;
	uint32 fx_flipper;
	uint32 fx_launch;
	uint32 fx_wall;
	uint32 fx_gameover;
	uint32 fx_bonus;
};
