#pragma once

#include "Module.h"
#include "Globals.h"

#include "box2d/box2d.h"

// Gravity in m/s^2. Screen Y grows DOWNWARDS and we convert meters <-> pixels without flipping Y,
// so a POSITIVE Y gravity makes bodies fall down on screen. That is why the world receives -GRAVITY_Y.
#define GRAVITY_X 0.0f
//*CHANGED*//
#define GRAVITY_Y -9.0f

// Units: Box2D works in meters (float), raylib draws in pixels (int)
#define PIXELS_PER_METER 50.0f // if touched change METER_PER_PIXEL too
#define METER_PER_PIXEL 0.02f  // this is 1 / PIXELS_PER_METER !

#define METERS_TO_PIXELS(m) ((int) floor(PIXELS_PER_METER * (m)))
#define PIXEL_TO_METERS(p)  ((float) METER_PER_PIXEL * (p))

//*CHANGED*//
// What every physics body is, so ModuleGame can decide what to do when the ball touches it
enum BodyKind
{
	KIND_NONE = 0,
	KIND_BALL,
	KIND_WALL,
	KIND_BOUNCY,   // slingshots: very high restitution
	KIND_BUMPER,   // gives points
	KIND_TARGET,   // gives points
	KIND_MOVER,    // moving platforms and the spinner: they give points
	KIND_GATE,     // one-way gate: the ball goes through in one direction only
	KIND_DRAIN,    // sensor at the bottom: ball here = game over
	KIND_FLIPPER,
	KIND_PLUNGER
};

// Small class to return to other modules to track position and rotation of physics bodies
class PhysBody
{
public:
	//*CHANGED*//
	PhysBody() : body(NULL), listener(NULL), kind(KIND_NONE), points(0), flash(0.0f), gate_nx(0.0f), gate_ny(0.0f)
	{}

	void GetPosition(int& x, int& y) const;
	//*CHANGED*//
	float GetY() const;                     // Y in pixels, as float (the int version loses precision)
	float GetRotation() const;
	//*CHANGED*//
	void GetVelocity(float& vx, float& vy) const;   // m/s
	float GetSpeed() const;                          // m/s
	bool Contains(int x, int y) const;
	int RayCast(int x1, int y1, int x2, int y2, float& normal_x, float& normal_y) const;

	//*CHANGED*//
	void SetPosition(int x, int y);
	void SetLinearVelocity(float vx, float vy);
	void SetAngularVelocity(float w);       // rad/s
	void ApplyForce(float fx, float fy);    // Newtons

public:
	b2Body* body;
	// Module that listens to the collisions of this body
	Module* listener;

	//*CHANGED*//
	// Game data
	int kind;       // BodyKind
	int points;     // score given when the ball touches it
	float flash;    // seconds left of the "I was hit" visual effect
	float gate_nx, gate_ny; // KIND_GATE: direction the ball is allowed to cross it
};

// Module --------------------------------------
class ModulePhysics : public Module, public b2ContactListener
{
public:
	ModulePhysics(Application* app, bool start_enabled = true);
	~ModulePhysics();

	bool Start();
	update_status PreUpdate();
	update_status PostUpdate();
	bool CleanUp();

	//*CHANGED*//
	// All creators take PIXELS. Restitution = bounciness (0 dead, 1 perfect, >1 adds energy)
	PhysBody* CreateCircle(int x, int y, int radius, b2BodyType type = b2_dynamicBody,
	                       float restitution = 0.0f, float friction = 0.2f, bool bullet = false);
	PhysBody* CreateRectangle(int x, int y, int half_width, int half_height, b2BodyType type = b2_dynamicBody,
	                          float restitution = 0.0f, float friction = 0.2f, float angle_deg = 0.0f);
	PhysBody* CreateRectangleSensor(int x, int y, int half_width, int half_height);
	//*CHANGED*//
	// Convex polygon (max 8 vertices). Used for flippers and slingshots. size = number of ints
	PhysBody* CreatePolygon(int x, int y, const int* points, int size, b2BodyType type = b2_staticBody,
	                        float restitution = 0.0f, float friction = 0.2f, float angle_deg = 0.0f);
	// loop = true: closed contour. loop = false: open line (walls). size = number of ints
	PhysBody* CreateChain(int x, int y, const int* points, int size, bool loop = true,
	                      float restitution = 0.0f, float friction = 0.2f);
	// Box that slides vertically (prismatic joint). (x, y) is its LOWEST position (spring compressed),
	// travel is how many pixels it can go up
	PhysBody* CreatePlunger(int x, int y, int half_width, int half_height, int travel);

	void DestroyBody(PhysBody* pbody);

	void BeginContact(b2Contact* contact) override;
	//*CHANGED*// Called every step while two fixtures touch, BEFORE the collision is solved: here we can cancel it
	void PreSolve(b2Contact* contact, const b2Manifold* oldManifold) override;

private:

	bool debug;
	b2World* world;

	// Static body with no fixtures, needed to create joints like the mouse joint
	b2Body* ground;
	b2MouseJoint* mouse_joint;
};
