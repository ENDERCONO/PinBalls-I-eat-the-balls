#include "Globals.h"
#include "Application.h"
#include "ModuleWindow.h"
#include "ModuleRender.h"
#include <math.h>

ModuleRender::ModuleRender(Application* app, bool start_enabled) : Module(app, start_enabled)
{
    background = RAYWHITE;
}

// Destructor
ModuleRender::~ModuleRender()
{}

// Called before render is available
bool ModuleRender::Init()
{
	LOG("Creating Renderer context");
	bool ret = true;

	//*CHANGED*//
	// Everything is drawn in WINDOW coordinates (1280 x 720) as always: the camera zoom of 0.5 shrinks it
	// into the small target. Sprites are authored at half size, so they map 1:1 to target pixels
	target = LoadRenderTexture(SCREEN_WIDTH / PIXEL_SCALE, SCREEN_HEIGHT / PIXEL_SCALE);
	SetTextureFilter(target.texture, TEXTURE_FILTER_POINT);

	low_res_camera.offset = Vector2{ 0.0f, 0.0f };
	low_res_camera.target = Vector2{ 0.0f, 0.0f };
	low_res_camera.rotation = 0.0f;
	low_res_camera.zoom = 1.0f / (float)PIXEL_SCALE;

	return ret;
}

// PreUpdate: clear buffer
//*CHANGED*//
// Start the frame BEFORE any module draws (ModuleRender is the last module, so its Update() runs
// after the scenes have already drawn: clearing there would wipe what was drawn)
update_status ModuleRender::PreUpdate()
{
	//*CHANGED*//
	BeginTextureMode(target);
	ClearBackground(background);
	BeginMode2D(low_res_camera);

	return UPDATE_CONTINUE;
}

update_status ModuleRender::Update()
{
	return UPDATE_CONTINUE;
}

// PostUpdate present buffer to screen
update_status ModuleRender::PostUpdate()
{
	//*CHANGED*//
	EndMode2D();
	EndTextureMode();

	//*CHANGED*//
	BeginDrawing();
	ClearBackground(BLACK);

	// Render textures are stored upside down: negative source height flips it back
	Rectangle source = { 0.0f, 0.0f, (float)target.texture.width, -(float)target.texture.height };
	Rectangle dest = { 0.0f, 0.0f, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT };
	DrawTexturePro(target.texture, source, dest, Vector2{ 0.0f, 0.0f }, 0.0f, WHITE);

	DrawFPS(10, SCREEN_HEIGHT - 24);

	EndDrawing();

	return UPDATE_CONTINUE;
}

// Called before quitting
bool ModuleRender::CleanUp()
{
	//*CHANGED*//
	UnloadRenderTexture(target);
	return true;
}

void ModuleRender::SetBackgroundColor(Color color)
{
	background = color;
}

// Draw to screen
bool ModuleRender::Draw(Texture2D texture, int x, int y, const Rectangle* section, double angle, int pivot_x, int pivot_y) const
{
	bool ret = true;

	float scale = 1.0f;
    Vector2 position = { (float)x, (float)y };
    Rectangle rect = { 0.f, 0.f, (float)texture.width, (float)texture.height };

    if (section != NULL) rect = *section;

    position.x = (float)(x-pivot_x) * scale + camera.x;
    position.y = (float)(y-pivot_y) * scale + camera.y;

	rect.width *= scale;
	rect.height *= scale;

    DrawTextureRec(texture, rect, position, WHITE);

	return ret;
}

bool ModuleRender::DrawText(const char * text, int x, int y, Font font, int spacing, Color tint) const
{
    bool ret = true;

    Vector2 position = { (float)x, (float)y };

    DrawTextEx(font, text, position, (float)font.baseSize, (float)spacing, tint);

    return ret;
}
