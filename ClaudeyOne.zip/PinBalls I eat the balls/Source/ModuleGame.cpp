//*CHANGED*// This whole file was rewritten: the original had the demo classes (PhysicEntity, Circle, Box, Chain, Rick)
#include "Globals.h"
#include "Application.h"
#include "ModuleRender.h"
#include "ModuleGame.h"
#include "ModuleAudio.h"
#include "ModulePhysics.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

//*CHANGED*// Table coordinate -> window pixel
static int TX(int x)
{
	return TABLE_X + x;
}

//*CHANGED*// Pixel art: everything is drawn at half resolution, so positions are snapped to even pixels
static float Snap(float v)
{
	return floorf(v / PIXEL_SCALE + 0.5f) * PIXEL_SCALE;
}

//*CHANGED*// The raylib default font is a pixel font: use sizes that are multiples of 20 to keep it crisp
static void DrawPixelText(const char* text, int x, int y, int size, Color color)
{
	DrawText(text, x + 2, y + 2, size, Color{ 0, 0, 0, 200 }); // hard shadow
	DrawText(text, x, y, size, color);
}

//*CHANGED*//
static void DrawPixelTextCentered(const char* text, int center_x, int y, int size, Color color)
{
	DrawPixelText(text, center_x - MeasureText(text, size) / 2, y, size, color);
}

//*CHANGED*//
ModuleGame::ModuleGame(Application* app, bool start_enabled) : Module(app, start_enabled)
{
	state = STATE_PLAYING;
	score = 0;
	best_score = 0;
	hits = 0;

	ball = NULL;
	plunger = NULL;
	drain = NULL;

	plunger_state = PLUNGER_LOADED;
	plunger_timer = 0.0f;
	ball_stuck_timer = 0.0f;
	ball_idle_timer = 0.0f;
	mover_time = 0.0f;
	bank_timer = 0.0f;
	drain_hit = false;
	trail_count = 0;

	tex_background = Texture2D{ 0 };
	tex_table = Texture2D{ 0 };
	tex_ball = Texture2D{ 0 };
	tex_bumper = tex_bumper_hit = Texture2D{ 0 };
	tex_diamond = tex_diamond_hit = Texture2D{ 0 };
	tex_flipper = Texture2D{ 0 };
	tex_kicker = tex_kicker_hit = Texture2D{ 0 };
	tex_target = tex_target_lit = Texture2D{ 0 };
	tex_plunger = Texture2D{ 0 };
	tex_platform_wide = tex_platform_small = tex_spinner = Texture2D{ 0 };

	fx_bumper = fx_kicker = fx_target = fx_flipper = fx_launch = fx_wall = fx_gameover = fx_bonus = 0;
}

ModuleGame::~ModuleGame()
{}

//*CHANGED*// Load assets
bool ModuleGame::Start()
{
	LOG("Loading game assets");

	App->renderer->camera.x = App->renderer->camera.y = 0;

	LoadAssets();
	BuildTable();
	Restart();

	return true;
}

//*CHANGED*// Unload assets
bool ModuleGame::CleanUp()
{
	LOG("Unloading game");

	if (ball != NULL)
	{
		App->physics->DestroyBody(ball);
		ball = NULL;
	}

	for (PhysBody* body : bodies)
		App->physics->DestroyBody(body);

	bodies.clear();
	bumpers.clear();
	diamonds.clear();
	kickers.clear();
	targets.clear();
	movers.clear();
	plunger = NULL;
	drain = NULL;
	flipper_left.body = NULL;
	flipper_right.body = NULL;

	UnloadAssets();

	return true;
}

//*CHANGED*//
void ModuleGame::LoadAssets()
{
	tex_background = LoadTexture("Assets/background.png");
	tex_table = LoadTexture("Assets/table.png");
	tex_ball = LoadTexture("Assets/ball.png");
	tex_bumper = LoadTexture("Assets/bumper.png");
	tex_bumper_hit = LoadTexture("Assets/bumper_hit.png");
	tex_diamond = LoadTexture("Assets/diamond.png");
	tex_diamond_hit = LoadTexture("Assets/diamond_hit.png");
	tex_flipper = LoadTexture("Assets/flipper.png");
	tex_kicker = LoadTexture("Assets/kicker.png");
	tex_kicker_hit = LoadTexture("Assets/kicker_hit.png");
	tex_target = LoadTexture("Assets/target.png");
	tex_target_lit = LoadTexture("Assets/target_lit.png");
	tex_plunger = LoadTexture("Assets/plunger.png");
	tex_platform_wide = LoadTexture("Assets/platform_wide.png");
	tex_platform_small = LoadTexture("Assets/platform_small.png");
	tex_spinner = LoadTexture("Assets/spinner.png");

	// Pixel art: NEAREST filter, never blur the pixels when a sprite is scaled or rotated
	Texture2D all[] = { tex_background, tex_table, tex_ball, tex_bumper, tex_bumper_hit, tex_diamond, tex_diamond_hit,
		tex_flipper, tex_kicker, tex_kicker_hit, tex_target, tex_target_lit, tex_plunger,
		tex_platform_wide, tex_platform_small, tex_spinner };
	for (Texture2D t : all)
		SetTextureFilter(t, TEXTURE_FILTER_POINT);

	fx_bumper = App->audio->LoadFx("Assets/bumper.wav");
	fx_kicker = App->audio->LoadFx("Assets/slingshot.wav");
	fx_target = App->audio->LoadFx("Assets/bonus.wav");
	fx_flipper = App->audio->LoadFx("Assets/flipper.wav");
	fx_launch = App->audio->LoadFx("Assets/launch.wav");
	fx_wall = App->audio->LoadFx("Assets/wall.wav");
	fx_gameover = App->audio->LoadFx("Assets/gameover.wav");
	fx_bonus = App->audio->LoadFx("Assets/bank.wav");
}

//*CHANGED*//
void ModuleGame::UnloadAssets()
{
	Texture2D all[] = { tex_background, tex_table, tex_ball, tex_bumper, tex_bumper_hit, tex_diamond, tex_diamond_hit,
		tex_flipper, tex_kicker, tex_kicker_hit, tex_target, tex_target_lit, tex_plunger,
		tex_platform_wide, tex_platform_small, tex_spinner };
	for (Texture2D t : all)
		UnloadTexture(t);
}

//*CHANGED*//
PhysBody* ModuleGame::AddBody(PhysBody* body, int kind, int points)
{
	body->kind = kind;
	body->points = points;
	bodies.push_back(body);
	return body;
}

// ---------------------------------------------------------------------------------------------
//*CHANGED*// Table: walls, flippers, plunger, bumpers, slingshots, targets and moving platforms
// ---------------------------------------------------------------------------------------------
void ModuleGame::BuildTable()
{
	ModulePhysics* physics = App->physics;

	// 1) Outer shell: right wall of the launch lane, a half circle arc on top, left wall and the
	//    slope that guides the ball to the left flipper. It is an OPEN chain (loop = false)
	std::vector<int> shell;
	shell.push_back(490); shell.push_back(700);
	shell.push_back(490); shell.push_back(250);
	for (int i = 1; i <= 36; ++i)
	{
		float a = (float)i * PI / 36.0f;
		shell.push_back((int)(250.0f + 240.0f * cosf(a)));
		shell.push_back((int)(250.0f - 240.0f * sinf(a)));
	}
	shell.push_back(10);  shell.push_back(520);
	//*CHANGED*// The guides end ON the flipper hub (not beside it), so the ball rolls onto the flipper without a step
	shell.push_back(126); shell.push_back(591);
	AddBody(physics->CreateChain(TABLE_X, 0, shell.data(), (int)shell.size(), false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 2) Wall between the launch lane (right) and the playfield. It ends before the arc so the
	//    ball can leave the lane
	const int lane_wall[] = { 455, 700, 455, 200 };
	AddBody(physics->CreateChain(TABLE_X, 0, lane_wall, 4, false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 3) Slope that guides the ball to the right flipper
	const int right_guide[] = { 455, 520, 338, 591 };
	AddBody(physics->CreateChain(TABLE_X, 0, right_guide, 4, false, WALL_RESTITUTION, 0.1f), KIND_WALL);

	// 3b) One-way gate at the exit of the launch lane: the ball can go out, but it can never come back in.
	//     (-50, -35) is the direction up-left, from the lane towards the playfield
	const int gate_line[] = { 455, 200, 490, 150 };
	PhysBody* gate = AddBody(physics->CreateChain(TABLE_X, 0, gate_line, 4, false, WALL_RESTITUTION, 0.1f), KIND_GATE);
	gate->gate_nx = -50.0f / 61.0f;
	gate->gate_ny = -35.0f / 61.0f;

	// 4) Drain: sensor below the screen. Ball touches it = game over
	drain = AddBody(physics->CreateRectangleSensor(TABLE_X + TABLE_W / 2, TABLE_H + 40, TABLE_W / 2 + 20, 28), KIND_DRAIN);
	drain->listener = this;

	// 5) Plunger. Its body is created at the compressed position
	plunger = AddBody(physics->CreatePlunger(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y, 15, 10, PLUNGER_COMPRESSED_Y - PLUNGER_REST_Y), KIND_PLUNGER);

	// 6) Flippers: kinematic bodies (we move them, they push the ball but nothing pushes them).
	//    The polygon is built from the pivot (0, 0) towards +X
	const int flipper_shape[] =
	{
		-10, -6,
		-10,  6,
		  0, 13,
		FLIPPER_LENGTH,  7,
		FLIPPER_LENGTH, -7,
		  0, -13
	};

	// Right flipper: rests at -210 degrees and rises 45 degrees to -165
	// Left flipper: mirror image, rests at +30 and rises to -15
	// (Box2D here has Y pointing down, so left and right use opposite signs)
	flipper_left.left = true;
	flipper_left.rest_angle = 30.0f * DEGTORAD;
	flipper_left.pressed_angle = (30.0f - FLIPPER_SWING_DEG) * DEGTORAD;
	flipper_left.body = AddBody(physics->CreatePolygon(TX(126), 600, flipper_shape, 12, b2_kinematicBody, 0.2f, 0.4f, 30.0f), KIND_FLIPPER);

	flipper_right.left = false;
	flipper_right.rest_angle = -210.0f * DEGTORAD;
	flipper_right.pressed_angle = (-210.0f + FLIPPER_SWING_DEG) * DEGTORAD;
	flipper_right.body = AddBody(physics->CreatePolygon(TX(338), 600, flipper_shape, 12, b2_kinematicBody, 0.2f, 0.4f, -210.0f), KIND_FLIPPER);

	// 7) Slingshots (very bouncy triangles above the flippers)
	const int kicker_left_shape[] = { 40, 430,  40, 500,  100, 535 };
	const int kicker_right_shape[] = { 425, 430,  425, 500,  365, 535 };

	Kicker kl = { AddBody(physics->CreatePolygon(TABLE_X, 0, kicker_left_shape, 6, b2_staticBody, SLINGSHOT_RESTITUTION, 0.0f), KIND_BOUNCY, POINTS_SLINGSHOT), TX(36), 426, false };
	Kicker kr = { AddBody(physics->CreatePolygon(TABLE_X, 0, kicker_right_shape, 6, b2_staticBody, SLINGSHOT_RESTITUTION, 0.0f), KIND_BOUNCY, POINTS_SLINGSHOT), TX(361), 426, true };
	kickers.push_back(kl);
	kickers.push_back(kr);

	// 8) Bumpers: a triangle of three round bumpers in the middle, they give points and bounce the ball
	const int bumper_pos[][2] = { { 170, 205 }, { 300, 205 }, { 235, 268 } };
	for (int i = 0; i < 3; ++i)
	{
		Bumper b;
		b.x = TX(bumper_pos[i][0]);
		b.y = bumper_pos[i][1];
		b.radius = 22;
		b.body = AddBody(physics->CreateCircle(b.x, b.y, b.radius, b2_staticBody, BUMPER_RESTITUTION, 0.0f), KIND_BUMPER, POINTS_BUMPER);
		bumpers.push_back(b);
	}

	// 9) Diamonds: rotated squares on the sides, bouncy
	const int diamond_shape[] = { 0, -20,  20, 0,  0, 20,  -20, 0 };
	const int diamond_pos[][2] = { { 78, 255 }, { 392, 255 } };
	for (int i = 0; i < 2; ++i)
	{
		Diamond d;
		d.x = TX(diamond_pos[i][0]);
		d.y = diamond_pos[i][1];
		d.body = AddBody(physics->CreatePolygon(d.x, d.y, diamond_shape, 8, b2_staticBody, DIAMOND_RESTITUTION, 0.0f), KIND_BOUNCY, POINTS_DIAMOND);
		diamonds.push_back(d);
	}

	// 10) Stand-up targets on both side walls. Hit all four to win the bank bonus
	const int target_pos[][2] = { { 22, 310 }, { 22, 360 }, { 443, 310 }, { 443, 360 } };
	for (int i = 0; i < 4; ++i)
	{
		Target t;
		t.x = TX(target_pos[i][0]);
		t.y = target_pos[i][1];
		t.half_w = 6;
		t.half_h = 22;
		t.lit = false;
		t.body = AddBody(physics->CreateRectangle(t.x, t.y, t.half_w, t.half_h, b2_staticBody, TARGET_RESTITUTION, 0.1f), KIND_TARGET, POINTS_TARGET);
		targets.push_back(t);
	}

	// 11) Moving platforms (kinematic bodies moved by UpdateMovers()). Slightly tilted and slippery
	//     so the ball can never ride them forever
	{
		// Slides left and right above the flippers
		Mover m;
		m.cx = (float)TX(232); m.cy = 490.0f; m.ax = 70.0f; m.ay = 0.0f;
		m.speed = 1.3f; m.phase = 0.0f; m.spinner = false;
		m.half_w = 32; m.half_h = 5; m.texture = 0;
		m.body = AddBody(physics->CreateRectangle((int)m.cx, (int)m.cy, m.half_w, m.half_h, b2_kinematicBody, MOVER_RESTITUTION, 0.05f, 8.0f), KIND_MOVER, POINTS_MOVER);
		movers.push_back(m);
	}
	{
		// Goes up and down on the right side
		Mover m;
		m.cx = (float)TX(385); m.cy = 350.0f; m.ax = 0.0f; m.ay = 50.0f;
		m.speed = 1.0f; m.phase = 0.0f; m.spinner = false;
		m.half_w = 24; m.half_h = 5; m.texture = 1;
		m.body = AddBody(physics->CreateRectangle((int)m.cx, (int)m.cy, m.half_w, m.half_h, b2_kinematicBody, MOVER_RESTITUTION, 0.05f, -12.0f), KIND_MOVER, POINTS_MOVER);
		movers.push_back(m);
	}
	{
		// Spinner: a bar that rotates forever on the left side
		Mover m;
		m.cx = (float)TX(118); m.cy = 345.0f; m.ax = 0.0f; m.ay = 0.0f;
		m.speed = 2.2f; m.phase = 0.0f; m.spinner = true;
		m.half_w = 40; m.half_h = 5; m.texture = 2;
		m.body = AddBody(physics->CreateRectangle((int)m.cx, (int)m.cy, m.half_w, m.half_h, b2_kinematicBody, MOVER_RESTITUTION, 0.2f, 0.0f), KIND_MOVER, POINTS_MOVER);
		movers.push_back(m);
	}
}

// ---------------------------------------------------------------------------------------------
//*CHANGED*// Game flow
// ---------------------------------------------------------------------------------------------
void ModuleGame::SpawnBall()
{
	if (ball != NULL)
	{
		App->physics->DestroyBody(ball);
		ball = NULL;
	}

	// Right side of the table, lying on top of the compressed plunger
	ball = App->physics->CreateCircle(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y - 10 - BALL_RADIUS - 1, BALL_RADIUS, b2_dynamicBody, 0.3f, 0.1f, true);
	ball->kind = KIND_BALL;
	ball->listener = this;
	ball->body->SetSleepingAllowed(false);

	trail_count = 0;
	ball_stuck_timer = 0.0f;
	ball_idle_timer = 0.0f;
}

//*CHANGED*// Put a new ball in the lane WITHOUT touching the score (used if the ball ever leaves the table)
void ModuleGame::RespawnBall()
{
	plunger_state = PLUNGER_LOADED;
	plunger_timer = PLUNGER_LAUNCH_DELAY;
	plunger->SetPosition(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y);
	plunger->SetLinearVelocity(0.0f, 0.0f);

	SpawnBall();
}

//*CHANGED*//
void ModuleGame::Restart()
{
	state = STATE_PLAYING;
	score = 0;
	hits = 0;
	drain_hit = false;
	bank_timer = 0.0f;
	popups.clear();
	particles.clear();

	for (Target& t : targets)
		t.lit = false;

	// Flippers back to their initial rotation
	Flipper* flippers[2] = { &flipper_left, &flipper_right };
	for (Flipper* f : flippers)
	{
		f->angle = f->rest_angle;
		f->omega = 0.0f;
		f->was_pressed = false;
		f->body->body->SetTransform(f->body->body->GetPosition(), f->rest_angle);
		f->body->SetAngularVelocity(0.0f);
	}

	// Compress the spring and wait: UpdatePlunger() will release it
	RespawnBall();
}

//*CHANGED*//
void ModuleGame::GameOver()
{
	state = STATE_GAME_OVER;

	if (score > best_score)
		best_score = score;

	// The ball is not needed any more
	App->physics->DestroyBody(ball);
	ball = NULL;

	// Freeze the flippers where they are
	flipper_left.body->SetAngularVelocity(0.0f);
	flipper_right.body->SetAngularVelocity(0.0f);

	App->audio->PlayFx(fx_gameover);
}

//*CHANGED*//
void ModuleGame::AddScore(int value, int x, int y, bool bonus)
{
	score += value;
	hits++;

	Popup p = { (float)x, (float)y, bonus ? 1.4f : 0.8f, value, bonus };
	popups.push_back(p);
}

//*CHANGED*// A little burst of square pixels
void ModuleGame::SpawnParticles(int x, int y, int count, Color color)
{
	for (int i = 0; i < count; ++i)
	{
		float angle = (float)(rand() % 628) / 100.0f;
		float speed = 60.0f + (float)(rand() % 140);

		Particle p;
		p.x = (float)x;
		p.y = (float)y;
		p.vx = cosf(angle) * speed;
		p.vy = sinf(angle) * speed;
		p.life = 0.35f + (float)(rand() % 30) / 100.0f;
		p.color = color;
		particles.push_back(p);
	}
}

// ---------------------------------------------------------------------------------------------
//*CHANGED*// Per frame logic
// ---------------------------------------------------------------------------------------------

//*CHANGED*// The flipper is a kinematic body: instead of teleporting it, we give it the angular velocity that
// makes it reach the animated angle in exactly one physics step. That way the ball is pushed with
// the real speed of the flipper.
void ModuleGame::UpdateFlipper(Flipper& flipper, bool pressed, float dt)
{
	if (pressed && flipper.was_pressed == false)
		App->audio->PlayFx(fx_flipper);

	if (pressed)
	{
		// Rotate 45 degrees in FLIPPER_RISE_TIME seconds, then hold
		float speed = (FLIPPER_SWING_DEG * DEGTORAD) / FLIPPER_RISE_TIME;
		float direction = (flipper.pressed_angle > flipper.rest_angle) ? 1.0f : -1.0f;

		flipper.angle += direction * speed * dt;

		if ((direction > 0.0f && flipper.angle >= flipper.pressed_angle) ||
			(direction < 0.0f && flipper.angle <= flipper.pressed_angle))
			flipper.angle = flipper.pressed_angle;

		flipper.omega = 0.0f;
	}
	else
	{
		// Released: damped spring towards the rest angle. Damping ratio < 1 = it passes the rest
		// angle a little bit and comes back (the "bounce")
		float k = FLIPPER_SPRING_FREQ * FLIPPER_SPRING_FREQ;
		float c = 2.0f * FLIPPER_DAMPING * FLIPPER_SPRING_FREQ;

		flipper.omega += (k * (flipper.rest_angle - flipper.angle) - c * flipper.omega) * dt;
		flipper.angle += flipper.omega * dt;

		if (fabsf(flipper.rest_angle - flipper.angle) < 0.0005f && fabsf(flipper.omega) < 0.01f)
		{
			flipper.angle = flipper.rest_angle;
			flipper.omega = 0.0f;
		}
	}

	float current_angle = flipper.body->GetRotation();
	flipper.body->SetAngularVelocity((flipper.angle - current_angle) / dt);

	flipper.was_pressed = pressed;
}

//*CHANGED*//
void ModuleGame::UpdatePlunger(float dt)
{
	if (plunger_state == PLUNGER_LOADED)
	{
		// Hold the plunger compressed
		plunger->SetPosition(TX(PLUNGER_X), PLUNGER_COMPRESSED_Y);
		plunger->SetLinearVelocity(0.0f, 0.0f);

		plunger_timer -= dt;
		if (plunger_timer <= 0.0f)
		{
			plunger_state = PLUNGER_RELEASED;
			App->audio->PlayFx(fx_launch);
		}
	}
	else
	{
		// Spring (Hooke's law): F = -k * x, x = distance below the rest position.
		// The prismatic joint upper limit stops the plunger at the rest position, so the ball
		// leaves with the speed the plunger had at that moment
		float x = PIXEL_TO_METERS(plunger->GetY() - (float)PLUNGER_REST_Y);
		if (x > 0.0f)
			plunger->ApplyForce(0.0f, -PLUNGER_SPRING_K * x);

		// If the ball falls back into the lane, load the spring and shoot again
		if (ball != NULL)
		{
			int bx, by;
			ball->GetPosition(bx, by);

			bool in_lane = (bx > TX(455) && by > 500);
			if (in_lane && ball->GetSpeed() < 1.0f) // resting on the spring it still jitters a little
				ball_stuck_timer += dt;
			else
				ball_stuck_timer = 0.0f;

			if (ball_stuck_timer > 0.6f)
			{
				ball_stuck_timer = 0.0f;
				plunger_state = PLUNGER_LOADED;
				plunger_timer = 0.8f;
			}
		}
	}
}

//*CHANGED*// Moving platforms: like the flippers, we give them the velocity that reaches the target position
// in one step, so the ball is carried and pushed by the real movement
void ModuleGame::UpdateMovers(float dt)
{
	mover_time += dt;

	for (Mover& m : movers)
	{
		if (m.spinner)
		{
			m.body->SetAngularVelocity(m.speed);
		}
		else
		{
			float s = sinf(m.speed * mover_time + m.phase);
			float target_x = m.cx + m.ax * s;
			float target_y = m.cy + m.ay * s;

			int x, y;
			m.body->GetPosition(x, y);

			// The int position loses precision: use the meters directly
			b2Vec2 pos = m.body->body->GetPosition();
			float vx = (PIXEL_TO_METERS(target_x) - pos.x) / dt;
			float vy = (PIXEL_TO_METERS(target_y) - pos.y) / dt;
			m.body->SetLinearVelocity(vx, vy);
		}
	}
}

//*CHANGED*// Safety nets so the game never gets stuck
void ModuleGame::UpdateBallSafety(float dt)
{
	if (ball == NULL)
		return;

	int bx, by;
	ball->GetPosition(bx, by);
	int lx = bx - TABLE_X;

	// The ball left the table somehow: new ball, same score
	if (lx < -30 || lx > TABLE_W + 30 || by < -30)
	{
		RespawnBall();
		return;
	}

	// Ball stopped in the playfield for 3 seconds (for example resting on a flipper): little push
	bool in_lane = (lx > 455 && by > 300);
	if (!in_lane && ball->GetSpeed() < 0.15f)
		ball_idle_timer += dt;
	else
		ball_idle_timer = 0.0f;

	if (ball_idle_timer > 3.0f)
	{
		ball_idle_timer = 0.0f;
		float sideways = ((float)(rand() % 100) / 100.0f - 0.5f) * 0.6f;
		ball->body->ApplyLinearImpulseToCenter(b2Vec2(sideways, -0.5f), true);
	}

	// Trail: remember the last positions
	for (int i = TRAIL_LENGTH - 1; i > 0; --i)
	{
		trail_x[i] = trail_x[i - 1];
		trail_y[i] = trail_y[i - 1];
	}
	trail_x[0] = (float)bx;
	trail_y[0] = (float)by;
	if (trail_count < TRAIL_LENGTH)
		trail_count++;
}

//*CHANGED*//
void ModuleGame::UpdateEffects(float dt)
{
	for (Bumper& b : bumpers)
		if (b.body->flash > 0.0f) b.body->flash -= dt;

	for (Diamond& d : diamonds)
		if (d.body->flash > 0.0f) d.body->flash -= dt;

	for (Kicker& k : kickers)
		if (k.body->flash > 0.0f) k.body->flash -= dt;

	for (Mover& m : movers)
		if (m.body->flash > 0.0f) m.body->flash -= dt;

	// Bank bonus: the four lights stay on for a moment and then go off
	if (bank_timer > 0.0f)
	{
		bank_timer -= dt;
		if (bank_timer <= 0.0f)
			for (Target& t : targets)
				t.lit = false;
	}

	for (size_t i = 0; i < popups.size();)
	{
		popups[i].timer -= dt;
		popups[i].y -= 30.0f * dt;

		if (popups[i].timer <= 0.0f)
			popups.erase(popups.begin() + i);
		else
			++i;
	}

	for (size_t i = 0; i < particles.size();)
	{
		Particle& p = particles[i];
		p.life -= dt;
		p.vy += 300.0f * dt;
		p.x += p.vx * dt;
		p.y += p.vy * dt;

		if (p.life <= 0.0f)
			particles.erase(particles.begin() + i);
		else
			++i;
	}
}

//*CHANGED*//
update_status ModuleGame::Update()
{
	const float dt = 1.0f / 60.0f; // same fixed step as ModulePhysics::PreUpdate()

	UpdateMovers(dt); // the platforms keep moving on the Game Over screen too

	if (state == STATE_PLAYING)
	{
		bool left_pressed = IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT);
		bool right_pressed = IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT);

		UpdateFlipper(flipper_left, left_pressed, dt);
		UpdateFlipper(flipper_right, right_pressed, dt);
		UpdatePlunger(dt);
		UpdateBallSafety(dt);

		if (ball != NULL)
		{
			// Safety: never let the ball go faster than the physics can handle
			if (ball->GetSpeed() > BALL_MAX_SPEED)
			{
				float vx, vy;
				ball->GetVelocity(vx, vy);
				float s = BALL_MAX_SPEED / ball->GetSpeed();
				ball->SetLinearVelocity(vx * s, vy * s);
			}

			// The ball reached the bottom of the map (Y max): the sensor tells us, and we also
			// check the position in case it ever misses
			if (drain_hit || ball->GetY() > (float)(TABLE_H + 60))
				GameOver();
		}
	}
	else
	{
		if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_R))
			Restart();
	}

	UpdateEffects(dt);

	// Draw (back to front)
	DrawBackground();
	DrawTable();
	DrawFlippers();
	DrawBall();
	DrawUI();

	if (state == STATE_GAME_OVER)
		DrawGameOver();

	return UPDATE_CONTINUE;
}

//*CHANGED*// The ball tells us what it touched. ModulePhysics calls this for every body with a listener
void ModuleGame::OnCollision(PhysBody* bodyA, PhysBody* bodyB)
{
	if (state != STATE_PLAYING || bodyA == NULL || bodyB == NULL)
		return;

	// Ball in the drain. It is called twice (ball,sensor) and (sensor,ball): both set the same flag
	if ((bodyA->kind == KIND_DRAIN && bodyB->kind == KIND_BALL) || (bodyA->kind == KIND_BALL && bodyB->kind == KIND_DRAIN))
	{
		// Never destroy bodies inside a collision callback: the world is locked.
		// Just remember it and do it in Update()
		drain_hit = true;
		return;
	}

	// From here on we only care about the callback of the ball (A = ball, B = what it touched)
	if (bodyA->kind != KIND_BALL)
		return;

	int bx, by;
	bodyA->GetPosition(bx, by);

	switch (bodyB->kind)
	{
	case KIND_BUMPER:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.15f;
		SpawnParticles(bx, by, 10, Color{ 255, 110, 200, 255 });
		App->audio->PlayFx(fx_bumper);
		break;

	case KIND_TARGET:
		for (Target& t : targets)
		{
			if (t.body != bodyB)
				continue;

			// First hit lights the target (full points), the next hits are worth less
			AddScore(t.lit ? POINTS_TARGET_LIT : POINTS_TARGET, bx, by);
			SpawnParticles(bx, by, 8, Color{ 255, 220, 90, 255 });
			App->audio->PlayFx(fx_target);
			t.lit = true;

			// All lit: bonus
			bool all_lit = true;
			for (const Target& other : targets)
				if (other.lit == false)
					all_lit = false;

			if (all_lit && bank_timer <= 0.0f)
			{
				AddScore(POINTS_BANK_BONUS, TABLE_X + TABLE_W / 2, 150, true);
				bank_timer = 0.8f;
				SpawnParticles(TABLE_X + TABLE_W / 2, 150, 30, Color{ 120, 240, 255, 255 });
				App->audio->PlayFx(fx_bonus);
			}
			break;
		}
		break;

	case KIND_BOUNCY:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.12f;
		SpawnParticles(bx, by, 6, Color{ 90, 255, 160, 255 });
		App->audio->PlayFx(fx_kicker);
		break;

	case KIND_MOVER:
		AddScore(bodyB->points, bx, by);
		bodyB->flash = 0.1f;
		SpawnParticles(bx, by, 4, Color{ 255, 255, 255, 255 });
		App->audio->PlayFx(fx_wall);
		break;

	case KIND_WALL:
		// Only the hard hits make noise, otherwise rolling along a wall sounds like a machine gun
		if (bodyA->GetSpeed() > 3.0f)
			App->audio->PlayFx(fx_wall);
		break;

	default:
		break;
	}
}

// ---------------------------------------------------------------------------------------------
//*CHANGED*// Drawing
// ---------------------------------------------------------------------------------------------

//*CHANGED*// Draws a (half size) pixel art texture scaled x2. (x, y) is where the origin (ox, oy) of the
// sprite goes, both in window pixels. The position is snapped to even pixels so the pixels stay crisp
void ModuleGame::DrawSprite(Texture2D tex, float x, float y, float w, float h, float ox, float oy, float rotation_deg, bool flip_x, bool flip_y)
{
	Rectangle source = { 0.0f, 0.0f, flip_x ? -(float)tex.width : (float)tex.width, flip_y ? -(float)tex.height : (float)tex.height };
	Rectangle dest = { Snap(x), Snap(y), w, h };
	DrawTexturePro(tex, source, dest, Vector2{ ox, oy }, rotation_deg, WHITE);
}

//*CHANGED*//
void ModuleGame::DrawBackground()
{
	DrawSprite(tex_background, 0, 0, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT, 0, 0);
	DrawSprite(tex_table, (float)TABLE_X, 0, (float)TABLE_W, (float)TABLE_H, 0, 0);
}

//*CHANGED*//
void ModuleGame::DrawTable()
{
	// Slingshots (the texture is the left one, the right one is the same image mirrored)
	for (const Kicker& k : kickers)
		DrawSprite(k.body->flash > 0.0f ? tex_kicker_hit : tex_kicker, (float)k.x, (float)k.y, 68, 114, 0, 0, 0.0f, k.mirrored);

	// Diamonds
	for (const Diamond& d : diamonds)
		DrawSprite(d.body->flash > 0.0f ? tex_diamond_hit : tex_diamond, (float)d.x, (float)d.y, 40, 40, 20, 20);

	// Targets: lit once they were hit
	for (const Target& t : targets)
		DrawSprite(t.lit ? tex_target_lit : tex_target, (float)t.x, (float)t.y, 12, 44, 6, 22);

	// Bumpers
	for (const Bumper& b : bumpers)
		DrawSprite(b.body->flash > 0.0f ? tex_bumper_hit : tex_bumper, (float)b.x, (float)b.y, 44, 44, 22, 22);

	// Moving platforms: drawn with the rotation of their physics body
	for (const Mover& m : movers)
	{
		float px = m.body->body->GetPosition().x * PIXELS_PER_METER;
		float py = m.body->body->GetPosition().y * PIXELS_PER_METER;
		float rot = m.body->GetRotation() * RAD2DEG;
		Texture2D tex = (m.texture == 0) ? tex_platform_wide : (m.texture == 1) ? tex_platform_small : tex_spinner;

		DrawSprite(tex, px, py, (float)m.half_w * 2, (float)m.half_h * 2, (float)m.half_w, (float)m.half_h, rot);

		if (m.spinner)
		{
			DrawCircle((int)Snap(px), (int)Snap(py), 8.0f, Color{ 255, 220, 90, 255 });
			DrawCircle((int)Snap(px), (int)Snap(py), 4.0f, Color{ 120, 60, 20, 255 });
		}
	}

	// One-way gate flap (the physics are in BuildTable / ModulePhysics::PreSolve)
	DrawLineEx(Vector2{ (float)TX(455), 200.0f }, Vector2{ (float)TX(490), 150.0f }, 4.0f, Color{ 255, 210, 80, 255 });

	// Plunger: zig-zag spring from the head down to the bottom of the lane + head texture
	int px, py;
	plunger->GetPosition(px, py);
	float top = (float)py + 10.0f;
	float bottom = (float)TABLE_H - 20.0f;
	const int coils = 9;
	for (int i = 0; i < coils; ++i)
	{
		float y1 = Snap(top + (bottom - top) * (float)i / (float)coils);
		float y2 = Snap(top + (bottom - top) * (float)(i + 1) / (float)coils);
		float x1 = (float)px + ((i % 2 == 0) ? -8.0f : 8.0f);
		float x2 = (float)px + ((i % 2 == 0) ? 8.0f : -8.0f);
		DrawLineEx(Vector2{ x1, y1 }, Vector2{ x2, y2 }, 4.0f, Color{ 190, 190, 205, 255 });
	}

	DrawSprite(tex_plunger, (float)px, (float)py, 30, 20, 15, 10);
}

//*CHANGED*//
void ModuleGame::DrawFlippers()
{
	Flipper* flippers[2] = { &flipper_left, &flipper_right };

	for (Flipper* f : flippers)
	{
		float x = f->body->body->GetPosition().x * PIXELS_PER_METER;
		float y = f->body->body->GetPosition().y * PIXELS_PER_METER;

		// The texture is 52 x 16 (drawn at 104 x 32) and its pivot is at (12, 16). The right flipper has
		// the angle of the left one + 180 degrees, so it is drawn upside down: flip it vertically
		DrawSprite(tex_flipper, x, y, 104, 32, 12, 16, f->body->GetRotation() * RAD2DEG, false, !f->left);
	}
}

//*CHANGED*//
void ModuleGame::DrawBall()
{
	// Trail
	for (int i = trail_count - 1; i >= 1; --i)
	{
		unsigned char alpha = (unsigned char)(120 - i * 16);
		float size = 20.0f - (float)i * 2.0f;
		DrawRectangle((int)Snap(trail_x[i] - size / 2), (int)Snap(trail_y[i] - size / 2), (int)size, (int)size, Color{ 140, 220, 255, alpha });
	}

	// Particles: little squares
	for (const Particle& p : particles)
	{
		unsigned char alpha = (unsigned char)(255.0f * (p.life > 0.3f ? 1.0f : p.life / 0.3f));
		DrawRectangle((int)Snap(p.x), (int)Snap(p.y), 4, 4, Color{ p.color.r, p.color.g, p.color.b, alpha });
	}

	if (ball == NULL)
		return;

	float x = ball->body->GetPosition().x * PIXELS_PER_METER;
	float y = ball->body->GetPosition().y * PIXELS_PER_METER;
	float d = (float)BALL_RADIUS * 2.0f;
	DrawSprite(tex_ball, x, y, d, d, d / 2.0f, d / 2.0f, ball->GetRotation() * RAD2DEG);
}

//*CHANGED*// Pixel art panel: dark fill, thick border, small highlight
void ModuleGame::DrawPanel(int x, int y, int w, int h)
{
	DrawRectangle(x, y, w, h, Color{ 12, 10, 38, 235 });
	DrawRectangleLinesEx(Rectangle{ (float)x, (float)y, (float)w, (float)h }, 4.0f, Color{ 90, 220, 255, 255 });
	DrawRectangleLinesEx(Rectangle{ (float)x + 8, (float)y + 8, (float)w - 16, (float)h - 16 }, 2.0f, Color{ 50, 70, 140, 255 });
	DrawRectangle(x + 4, y + 4, w - 8, 4, Color{ 255, 255, 255, 40 });
}

//*CHANGED*//
void ModuleGame::DrawUI()
{
	// Floating "+100" where the points were earned
	for (const Popup& p : popups)
	{
		unsigned char alpha = (unsigned char)(255.0f * (p.timer > 0.4f ? 1.0f : p.timer / 0.4f));
		if (p.bonus)
			DrawPixelTextCentered(TextFormat("BONUS +%d", p.value), (int)p.x, (int)p.y - 30, 40, Color{ 120, 240, 255, alpha });
		else
			DrawPixelText(TextFormat("+%d", p.value), (int)p.x - 20, (int)p.y - 30, 20, Color{ 255, 240, 120, alpha });
	}

	// Left panel: score
	const int left_center = TABLE_X / 2;
	DrawPanel(30, 40, TABLE_X - 60, 360);

	DrawPixelTextCentered("PINBALLS", left_center, 66, 40, Color{ 255, 90, 200, 255 });
	DrawPixelTextCentered("SCORE", left_center, 140, 20, Color{ 150, 170, 210, 255 });
	DrawPixelTextCentered(TextFormat("%06d", score), left_center, 170, 60, Color{ 255, 230, 90, 255 });
	DrawPixelTextCentered("BEST", left_center, 250, 20, Color{ 150, 170, 210, 255 });
	DrawPixelTextCentered(TextFormat("%06d", best_score), left_center, 280, 40, Color{ 120, 240, 255, 255 });
	DrawPixelTextCentered(TextFormat("HITS %d", hits), left_center, 350, 20, Color{ 150, 170, 210, 255 });

	// Bank lights (the four targets): shows how close the bonus is
	int lit = 0;
	for (const Target& t : targets)
		if (t.lit) lit++;
	for (int i = 0; i < 4; ++i)
		DrawRectangle(left_center - 52 + i * 28, 320, 20, 12, i < lit ? Color{ 255, 220, 90, 255 } : Color{ 60, 50, 90, 255 });

	// Right panel: controls
	const int right_x = TABLE_X + TABLE_W + 30;
	DrawPanel(right_x, 40, TABLE_X - 60, 280);

	DrawPixelTextCentered("CONTROLS", right_x + (TABLE_X - 60) / 2, 66, 40, Color{ 255, 90, 200, 255 });
	DrawPixelText("A / <   LEFT", right_x + 30, 140, 20, WHITE);
	DrawPixelText("D / >   RIGHT", right_x + 30, 175, 20, WHITE);
	DrawPixelText("ENTER   RETRY", right_x + 30, 210, 20, WHITE);
	DrawPixelText("F1      DEBUG", right_x + 30, 245, 20, WHITE);
}

//*CHANGED*//
void ModuleGame::DrawGameOver()
{
	const int cx = SCREEN_WIDTH / 2;

	DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Color{ 0, 0, 0, 175 });
	DrawPanel(cx - 300, 140, 600, 420);

	DrawPixelTextCentered("GAME OVER", cx, 190, 80, Color{ 255, 70, 90, 255 });
	DrawPixelTextCentered(TextFormat("SCORE %06d", score), cx, 300, 40, Color{ 255, 230, 90, 255 });

	if (score > 0 && score >= best_score)
		DrawPixelTextCentered("NEW RECORD!", cx, 360, 40, Color{ 120, 240, 255, 255 });

	// TRY AGAIN button
	Rectangle button = { (float)(cx - 160), 440.0f, 320.0f, 80.0f };
	bool hover = CheckCollisionPointRec(GetMousePosition(), button);

	DrawRectangle((int)button.x, (int)button.y + 8, (int)button.width, (int)button.height, Color{ 90, 20, 70, 255 }); // pixel "3D" edge
	DrawRectangle((int)button.x, (int)button.y, (int)button.width, (int)button.height, hover ? Color{ 255, 120, 210, 255 } : Color{ 210, 60, 160, 255 });
	DrawRectangleLinesEx(button, 4.0f, WHITE);
	DrawPixelTextCentered("TRY AGAIN", cx, 464, 40, WHITE);

	if (hover && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
		Restart();
}
